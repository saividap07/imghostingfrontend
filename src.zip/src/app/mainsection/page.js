"use client"

import React, { useEffect, useState } from 'react'
import Navbar from '../navbar/page';
import Category from '../category/page';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPosts } from '@/redux/features/slice';



import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart } from '@fortawesome/free-solid-svg-icons';



export default function page(){

  const [isClicked, setIsClicked] = useState(false);

  const handleClick = () => {
    setIsClicked(!isClicked);
  };




  
  const {posts} = useSelector((state)=>state.postsReducer);

  const dispatch = useDispatch();

  useEffect(()=>{
      dispatch(fetchPosts());
  },[]);

  console.log(posts);

  return (
    <>
      <Navbar />

      <Category />

      <main role="main">
        <section className="mt-4 mb-5">
          <div className="container-fluid">
            <div className="row">
              <div className="card-columns">

              {posts && posts.map((p)=>(

             
                <div class="card">
                  <a href={'/detail/' + p.pid}>
                    <img
                      class="card-img-top"
                      src = {`http://localhost:8000/img/${JSON.parse(p.photopath)[0]}`}

                      alt="Card image cap"
                      style={{ height: "auto" }}
                    />
                  </a>
                  <div
                    class="card-body"
                    style={{ height: "100px", backgroundColor: "#63656B" }}
                  >
                    <div className="mb-5">
                      <p
                        class="card-text text-white"
                        style={{ fontSize: "14px" }}
                      >
                        {p.title}
                      </p>
                      <hr />
                      <span style={{ fontSize: "13px", color: "#fff" }}>
                        {/* <a href="#" id="icon-link">
                          <i
                            class="fa fa-heart"
                            aria-hidden="true" 
                            style={{ fontSize: "14px", color: "#fff" }}
                          ></i>
                        </a> */}
                          <FontAwesomeIcon
        icon={faHeart}
        onClick={handleClick}
        className={isClicked ? 'heart-clicked' : 'heart'}
      />

                        <span className="mx-1">2,877</span>
                      </span>

                      <span style={{ fontSize: "13px", color: "#fff" }}>
                        <i
                          class="fa fa-comment ml-4"
                          style={{ color: "#fff" }}
                        ></i>
                        <span className="mx-1">2k</span>
                      </span>

                      <span style={{ fontSize: "13px", color: "#fff" }}>
                        <i class="fa fa-eye ml-4" style={{ color: "#fff" }}></i>
                        <span className="mx-1">2,877</span>
                      </span>
                    </div>
                  </div>
                </div>

              ))}













                <div className="card card-pin">
                  <img
                    className="card-img"
                    src="https://images.unsplash.com/photo-1518707399486-6d702a84ff00?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=b5bb16fa7eaed1a1ed47614488f7588d&auto=format&fit=crop&w=500&q=60"
                    alt="Card image"
                  />
                  <div className="overlay">
                    <h2 className="card-title title">Cool Title</h2>
                    <div className="more">
                      <a href="post.html">
                        <i
                          className="fa fa-arrow-circle-o-right"
                          aria-hidden="true"
                        />{" "}
                        More{" "}
                      </a>
                    </div>
                  </div>
                </div>
                <div className="card card-pin">
                  <img
                    className="card-img"
                    src="https://images.unsplash.com/photo-1519408299519-b7a0274f7d67?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=d4891b98f4554cc55eab1e4a923cbdb1&auto=format&fit=crop&w=500&q=60"
                    alt="Card image"
                  />
                  <div className="overlay">
                    <h2 className="card-title title">Cool Title</h2>
                    <div className="more">
                      <a href="post.html">
                        <i
                          className="fa fa-arrow-circle-o-right"
                          aria-hidden="true"
                        />{" "}
                        More{" "}
                      </a>
                    </div>
                  </div>
                </div>
                <div className="card card-pin">
                  <img
                    className="card-img"
                    src="https://images.unsplash.com/photo-1506706435692-290e0c5b4505?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=0bb464bb1ceea5155bc079c4f50bc36a&auto=format&fit=crop&w=500&q=60"
                    alt="Card image"
                  />
                  <div className="overlay">
                    <h2 className="card-title title">Cool Title</h2>
                    <div className="more">
                      <a href="post.html">
                        <i
                          className="fa fa-arrow-circle-o-right"
                          aria-hidden="true"
                        />{" "}
                        More{" "}
                      </a>
                    </div>
                  </div>
                </div>
                <div className="card card-pin">
                  <img
                    className="card-img"
                    src="https://images.unsplash.com/photo-1512355144108-e94a235b10af?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=c622d56d975113a08c71c912618b5f83&auto=format&fit=crop&w=500&q=60"
                    alt="Card image"
                  />
                  <div className="overlay">
                    <h2 className="card-title title">Cool Title</h2>
                    <div className="more">
                      <a href="post.html">
                        <i
                          className="fa fa-arrow-circle-o-right"
                          aria-hidden="true"
                        />{" "}
                        More{" "}
                      </a>
                    </div>
                  </div>
                </div>




                
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
