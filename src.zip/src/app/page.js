import Image from 'next/image'
import Mainsection from './mainsection/page'
export default function Home() {
  return (
   <main>

    <Mainsection/>
   </main>
  )
}
