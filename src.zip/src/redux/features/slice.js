import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import axios from "axios";

export const fetchPosts = createAsyncThunk('fetchposts', async(e)=>{
    const response = await axios.get('http://localhost:8000/api/post');

    return response.data;
});


export const addpost = createAsyncThunk('addpost', async (data) => {
  const { title, description, photopath } = data;

  const formdata = new FormData();
  formdata.append('title', title);
  formdata.append('description', description);

  // Ensure photopath is an array
  if (Array.isArray(photopath)) {
      photopath.forEach((photopath, index) => {
          formdata.append('photopath[]', photopath); // Use '[]' to indicate an array
      });
  } else {
      formdata.append('photopath', photopath); // If it's a single photo, still append it
  }

  const response = await axios.post('http://localhost:8000/api/post', formdata).catch((error) => {
    console.error('Error:', error);
  });
  
  console.log(response);
  return response.data;
});



export const fetchParticularPost = createAsyncThunk('fetchparticularpost', async(id)=>{
    console.log('id:',id)
    const response = await axios.get('http://localhost:8000/api/post/'+id);

    return response.data
})






export const posts = createSlice({
    name:'posts',
    initialState:{
      title:'',
      description:'',
      photopath:'',
        posts:[],
        detailPost:{}

    },

    reducers:{
      setTitle:(state,payload)=>{
        state.title = payload.payload
    },
    setDescription:(state,payload)=>{
      state.description = payload.payload
  },
  setPhoto:(state,payload)=>{
    state.photopath = payload.payload
},

    },

    extraReducers:{
        [fetchPosts.fulfilled]:(state, action)=>{
            state.posts = action.payload;
        },

        [fetchParticularPost.fulfilled]:(state,action)=>{
            state.detailPost = action.payload
        },
        [addpost.fulfilled]:()=>{
          alert("Post Added");            
      }
    }
});

export const {setTitle,setDescription,setPhoto} = posts.actions;
export default posts.reducer;