import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import axios from "axios";

export const addlogin = createAsyncThunk('addlogin', async(data)=>{
   
    const {email,password} = data;

    const formdata = new FormData();
formdata.append('email', email);
formdata.append('password', password);

    const response = await axios.post('http://localhost:8000/api/login', formdata);

    console.log(response);
    const token = response.data.token; // Assuming the token is in the response data
   // const uid = localStorage.setItem('token', response.data.token);
    
   console.log(token);
  return { token, userData: response.data };
    return response.data;
}); 



export const login = createSlice({
    name:'login',
    initialState:{
      
        email:'',
        password:'',
        
        login:[],
        token: null,
        

    },

    reducers:{
       
        setEmail:(state,payload)=>{
            state.email = payload.payload
        },
        setPassword:(state,payload)=>{
            state.password = payload.payload
        },
        

    },

    extraReducers:{
        [addlogin.fulfilled]:(state,action)=>{
            state.token = action.payload.token; 
            alert("Login Successfully done");            
        }

       
    }
}); 
export const {setEmail,setPassword} = login.actions;
export default login.reducer;