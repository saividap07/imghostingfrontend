
"use client"
import { useDispatch, useSelector } from 'react-redux';
import { addpost,setTitle,setDescription,setPhoto} from '@/redux/features/slice';

import React, { useState,useEffect } from 'react';
import Navbar from "../navbar/page";
export default function Page() {
  const [cards, setCards] = useState([0]);

  const handleAddCard = () => {
    setCards([...cards, cards.length]);
  };

  const handleDeleteAllPosts = () => {
    if (cards.length > 1) {
      setCards([0]);
    }
  };

  const handleDeleteCard = (index) => {
    if (cards.length > 1) {
      const updatedCards = cards.filter((_, i) => i !== index);
      setCards(updatedCards);
    }
  };






  // const {title,description,photpath} = useSelector((state)=>state.post);

  const {title,description,photpath} = useSelector((state)=>state.postsReducer);

  const dispatch = useDispatch();
  

  
  const handleSubmit = (e)=>{
    e.preventDefault();

    const data = {
      title:title,
      description:description,
      photpath:photpath,
   
    };
    dispatch(addpost(data));
  };

  return (
    <>
      <Navbar />
      <div style={{ backgroundColor: "#26333D", color: "#fff", paddingTop: "500px", paddingBottom: "500px" }}>
        <div className="container-fluid" >
          <div className='row' style={{ marginTop: "-500px" }}>
            {cards.map((cardIndex, index) => (
              <div className='col-md-8 mt-5' key={cardIndex} >
              <form method="post" action="/upload" enctype="multipart/form-data">


                <div className="card">

                  <div className="card-header">

                    <input
                      type="text"
                      name="title"
                      id=""
                      className="form-control"
                      placeholder="Enter card title..."
                      style={{ border: "none" }}
                      onChange={(e)=>dispatch(setTitle(e.target.value))}
                    />
                  </div>
                  <ul className="list-group list-group-flush" style={{ height: "150px" }}>
                  <input
  type="file"
  name="photopath"
  accept="image/*"
  id="basic-icon-default-email"
  multiple
  onChange={(e) => dispatch(setPhoto(e.target.files))} // Use e.target.files to get selected files
/>


                  </ul>
                  <div className="card-header">
                    <input
                      type="text"
                      name="description"
                      id=""
                      className="form-control"
                      placeholder="Enter card Description..."
                      style={{ border: "none" }}
                      onChange={(e)=>dispatch(setDescription(e.target.value))}
                    />
                  </div>
                  {index > 0 && (
                    <button
                      type="button"
                      className="btn btn-primary mt-2"
                      onClick={() => handleDeleteCard(index)}
                    >
                      Delete
                    </button>
                  )}
                </div>
                <button type="submit" onClick={handleSubmit} class="btn btn-light m-1">To Community</button>
</form>

                <div className="col-md-4">
                  <button
                    type="button"
                    className="btn btn-primary mt-2"
                    onClick={handleAddCard}
                  >
                    Add more Post
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger mt-2"
                    onClick={handleDeleteAllPosts}
                  >
                    Delete All Posts
                  </button>

                </div>
              </div>





            ))}

            <div className='col-md-4 mt-5'>
              <div className="fixed-right">
                <h6><b>POST</b></h6>
                <button type="submit" class="btn btn-light m-1"> Grab Link</button>

                <div class="container mt-4">
                  <h6>ADD TAGS</h6>
                  <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle" type="button" data-toggle="dropdown">+ TAG
                      <span class="caret"></span></button>
                    <ul class="dropdown-menu p-2">
                      <li><a href="#">Phantom</a></li>
                      <li><a href="#">Cluster</a></li>
                    </ul>
                  </div>

                  <div className='mt-5'>
                    <p><b>IMG TOOLS</b></p>
                    <ul>
                      <li><span><i class="fa fa-plus" aria-hidden="true"></i> <a className='ml-2' href=''>Add more images</a></span>
                      </li>
                    
                    <li>
                      <span><i class="fa fa-download"></i>
                        <a className='ml-2' href=''>Download Post</a></span>
                    </li>
                    <li> <span><i class="fa fa-trash-o"></i>
                      <a className='ml-2' href=''>Add more images</a></span></li>
                      </ul>
                  </div>
                </div>


              </div>
            </div>

          </div>
        </div>
      </div>

    </>
  );
}
