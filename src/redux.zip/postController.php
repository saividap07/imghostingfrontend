<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\user;
use App\Models\post;
use DB;

class postController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $post=DB::table('posts')
                ->join('users','posts.userid','=','users.id')
                ->select('*','posts.id as pid')
                ->get();
        return response()->json($post);

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
     public function store(Request $request)
   {
       $userid = $request->get('userid');
       $title = $request->get('title');
       $description = $request->get('description');
       $views = $request->get('views');

       $images = [];
 if ($request->hasFile('photopath')) {
     foreach ($request->file('photopath') as $image) {
         $imgname = $image->getClientOriginalName();
         $image->move(public_path('img'), $imgname);
         $images[] = $imgname;
     }
 }



 $insert = new post([
'userid' => $userid,
'title' => $title,
'description' => $description,
'photopath' => json_encode($images), // Store image file names
'active' => '0',
'views' => $views,
]);


       $insert->save();
       return "Data Inserted";
   }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //

        // $post = post::find($id);

        $post = post::join('users','posts.userid','=','users.id')->where('posts.id','=',$id)->first();

        return response()->json($post);

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $delete=post::find($id);
        $delete->delete();
        echo "Record Deleted";
    }
}
